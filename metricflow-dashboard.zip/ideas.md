# MetricFlow Analytics Dashboard - Design Philosophy

## Reference Brief
Build a clean, minimal analytics dashboard for MetricFlow SaaS tool with:
- **Core Features:** KPI cards (Revenue, Active Users, Conversions), Line chart + bar chart sections, Filter bar (date range, segment), Data table of recent activity, Sidebar navigation
- **Visual Direction:** Minimal, rounded corners, white and pastel colors

---

## Chosen Design Approach: "Soft Clarity"

### Design Movement
**Soft Minimalism with Pastel Warmth** — inspired by modern SaaS dashboards (Notion, Figma) but with a distinctly approachable, human-centered aesthetic. The design rejects cold, corporate minimalism in favor of warm pastels, generous breathing room, and soft edges that feel inviting rather than sterile.

### Core Principles
1. **Clarity Through Restraint** — Every element earns its place. No decorative clutter; information hierarchy is enforced through typography, color, and spacing.
2. **Soft Geometry** — Rounded corners (0.65rem base radius) on cards, buttons, and inputs create a friendly, modern feel without looking cartoonish.
3. **Pastel Warmth** — Soft, desaturated colors (cream, pale rose, soft sage, powder blue) replace harsh grays and pure whites. This reduces eye strain and creates a welcoming workspace.
4. **Breathing Space** — Generous padding and margins between sections allow content to "float" rather than feel cramped. Whitespace is a design tool.

### Color Philosophy
**Palette Reasoning:** Pastels are psychologically calming and reduce cognitive load—ideal for data-heavy interfaces where users spend extended periods. The palette avoids saturation to prevent visual fatigue.

- **Primary Background:** Off-white (`oklch(0.98 0.001 286)`) — slightly warmer than pure white, reduces glare
- **Card Backgrounds:** Soft cream (`oklch(0.99 0.001 80)`) — creates subtle depth without harsh contrast
- **Accent Colors:**
  - Soft Sage (`oklch(0.85 0.05 145)`) — for positive metrics (revenue, growth)
  - Powder Blue (`oklch(0.80 0.08 260)`) — for primary actions and charts
  - Pale Rose (`oklch(0.88 0.04 15)`) — for warnings or secondary highlights
- **Text:** Dark slate (`oklch(0.235 0.015 65)`) — high contrast but not harsh black

### Layout Paradigm
**Asymmetric Dashboard Grid** — Sidebar (fixed, 240px) on the left; main content area uses a flexible grid:
- Top: Filter bar (date range, segment dropdown) with rounded pill-style inputs
- Middle: KPI cards in a 3-column grid (responsive to 2 or 1 on mobile)
- Below: Two chart sections side-by-side (line chart left, bar chart right; stack on tablet)
- Bottom: Data table with alternating row backgrounds (subtle pastel stripes)

The sidebar remains visible at all times, anchoring navigation. Content scrolls independently.

### Signature Elements
1. **Soft Card Containers** — All data blocks (KPI cards, charts, table) live in rounded cards with a single, subtle shadow (`0 1px 3px rgba(0,0,0,0.08)`) and a 1px border in a very light gray (`oklch(0.92 0.004 286)`).
2. **Metric Badges** — KPI cards display a small, rounded badge (e.g., "+12.5%") in a pastel accent color to show trend direction at a glance.
3. **Gradient Accents** — Chart areas use subtle gradients (e.g., powder blue to pale rose) to add depth without overwhelming.

### Interaction Philosophy
- **Hover States:** Cards and buttons lift slightly (shadow increases, background subtly brightens) to signal interactivity.
- **Smooth Transitions:** All state changes (hover, focus, active) use 150–200ms ease-out transitions for snappy but not jarring feedback.
- **Focus Indicators:** Keyboard focus rings use the primary accent color (powder blue) with a 2px outline, always visible.
- **Micro-interactions:** Buttons scale to 0.98 on click; filter inputs show a subtle focus ring; chart tooltips fade in smoothly.

### Animation
- **Entrance:** KPI cards and chart sections fade in and slide up slightly (opacity 0 → 1, translateY 8px → 0) over 300ms with 50ms stagger per item.
- **Hover:** Cards and buttons transition to a lifted state (shadow depth increases, background lightens) over 150ms.
- **Loading:** Skeleton loaders use a gentle shimmer animation (opacity pulse) to indicate data is loading.
- **Transitions:** All color and transform changes use `cubic-bezier(0.23, 1, 0.32, 1)` (snappy ease-out) for responsive feel.

### Typography System
- **Display Font:** "Geist" (or fallback "system-ui") — modern, geometric, used for page titles and KPI labels
- **Body Font:** "Inter" — clean, highly legible, used for descriptions, table text, and UI labels
- **Font Hierarchy:**
  - H1 (Page Title): 32px, 600 weight, dark slate
  - H2 (Section Titles): 20px, 600 weight, dark slate
  - H3 (Card Labels): 14px, 600 weight, muted foreground
  - Body (Table, Descriptions): 14px, 400 weight, foreground
  - Small (Timestamps, Helpers): 12px, 400 weight, muted foreground

### Brand Essence
**One-liner:** MetricFlow is the intuitive, human-centered analytics dashboard for SaaS teams who want clarity without complexity.

**Personality:** Approachable, professional, calm, trustworthy.

### Brand Voice
- **Headlines:** Action-oriented, clear, no jargon. E.g., "Your metrics at a glance" instead of "Real-time analytics aggregation."
- **CTAs:** Conversational and direct. E.g., "View details" instead of "Proceed."
- **Microcopy:** Warm and helpful. E.g., "No data yet—check back soon" instead of "Error: null."

### Wordmark & Logo
**Logo Concept:** A minimalist, geometric mark combining a flowing line (representing data flow) and a circle (representing completeness/wholeness). The mark is a bold, single-color graphic on a transparent background. No text in the logo itself; the wordmark "MetricFlow" is set in Geist Bold below or beside the mark.

### Signature Brand Color
**Powder Blue** (`oklch(0.80 0.08 260)`) — This is MetricFlow's ownable color. It appears in the logo, primary buttons, chart accents, and active navigation items. It's calm and trustworthy, fitting for a data platform.

---

## Implementation Notes
- All cards use the base radius (0.65rem) for consistency.
- Shadows are kept minimal (0 1px 3px for cards, 0 4px 12px for modals) to maintain the light, airy feel.
- The sidebar is always visible on desktop; on mobile, it collapses to a hamburger menu.
- Charts use the pastel gradient palette to maintain visual cohesion with the rest of the dashboard.
- The data table uses alternating row backgrounds (every other row gets a very light pastel tint) to improve readability without harsh lines.
