import { DollarSign, Users, Zap } from "lucide-react";
import DashboardLayout from "@/components/DashboardLayout";
import KPICard from "@/components/KPICard";
import FilterBar from "@/components/FilterBar";
import ChartSection from "@/components/ChartSection";
import ActivityTable from "@/components/ActivityTable";

/**
 * MetricFlow Analytics Dashboard
 * Design: Soft Clarity - Minimal, rounded corners, pastel colors
 * Features: KPI cards, charts, filters, activity table, sidebar navigation
 */
export default function Home() {
  return (
    <DashboardLayout>
      {/* Page Header */}
      <div className="mb-8 pb-4 border-b border-border">
        <h1 className="text-4xl font-bold text-foreground mb-2">Your Metrics at a Glance</h1>
        <p className="text-base text-muted-foreground">
          Real-time insights into revenue, users, and conversions. Track what matters most.
        </p>
      </div>

      {/* Filter Bar */}
      <FilterBar />

      {/* KPI Cards Grid */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
        <KPICard
          title="Total Revenue"
          value="$24,580"
          trend={12.5}
          trendLabel="vs last week"
          icon={<DollarSign className="w-6 h-6" />}
          color="blue"
        />
        <KPICard
          title="Active Users"
          value="3,842"
          trend={8.2}
          trendLabel="vs last week"
          icon={<Users className="w-6 h-6" />}
          color="sage"
        />
        <KPICard
          title="Conversions"
          value="284"
          trend={-2.1}
          trendLabel="vs last week"
          icon={<Zap className="w-6 h-6" />}
          color="rose"
        />
      </div>

      {/* Charts Section */}
      <ChartSection />

      {/* Activity Table */}
      <ActivityTable />
    </DashboardLayout>
  );
}
