import { Calendar, Filter } from "lucide-react";
import { useState } from "react";
import { Button } from "@/components/ui/button";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";

interface FilterBarProps {
  onDateRangeChange?: (range: string) => void;
  onSegmentChange?: (segment: string) => void;
}

export default function FilterBar({
  onDateRangeChange,
  onSegmentChange,
}: FilterBarProps) {
  const [dateRange, setDateRange] = useState("7d");
  const [segment, setSegment] = useState("all");

  const handleDateChange = (value: string) => {
    setDateRange(value);
    onDateRangeChange?.(value);
  };

  const handleSegmentChange = (value: string) => {
    setSegment(value);
    onSegmentChange?.(value);
  };

  return (
    <div className="flex flex-col sm:flex-row gap-4 mb-8 bg-card border border-border rounded-lg p-4 shadow-sm">
      <div className="flex items-center gap-2 text-muted-foreground">
        <Filter className="w-4 h-4" />
        <span className="text-sm font-medium">Filters:</span>
      </div>

      <div className="flex flex-col sm:flex-row gap-3 flex-1">
        {/* Date Range Selector */}
        <div className="flex items-center gap-2">
          <Calendar className="w-4 h-4 text-muted-foreground" />
          <Select value={dateRange} onValueChange={handleDateChange}>
            <SelectTrigger className="w-40 h-10">
              <SelectValue placeholder="Select date range" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="7d">Last 7 days</SelectItem>
              <SelectItem value="30d">Last 30 days</SelectItem>
              <SelectItem value="90d">Last 90 days</SelectItem>
              <SelectItem value="1y">Last year</SelectItem>
            </SelectContent>
          </Select>
        </div>

        {/* Segment Selector */}
        <Select value={segment} onValueChange={handleSegmentChange}>
          <SelectTrigger className="w-40 h-10">
            <SelectValue placeholder="Select segment" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="all">All segments</SelectItem>
            <SelectItem value="premium">Premium</SelectItem>
            <SelectItem value="standard">Standard</SelectItem>
            <SelectItem value="free">Free</SelectItem>
          </SelectContent>
        </Select>

        {/* Reset Button */}
        <Button
          variant="outline"
          size="sm"
          onClick={() => {
            setDateRange("7d");
            setSegment("all");
            onDateRangeChange?.("7d");
            onSegmentChange?.("all");
          }}
          className="ml-auto"
        >
          Reset
        </Button>
      </div>
    </div>
  );
}
