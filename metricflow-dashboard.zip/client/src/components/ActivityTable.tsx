import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { Badge } from "@/components/ui/badge";

const activityData = [
  {
    id: 1,
    user: "Alice Johnson",
    action: "Purchase",
    amount: "$299.00",
    status: "completed",
    timestamp: "2 hours ago",
  },
  {
    id: 2,
    user: "Bob Smith",
    action: "Signup",
    amount: "Free",
    status: "pending",
    timestamp: "4 hours ago",
  },
  {
    id: 3,
    user: "Carol White",
    action: "Upgrade",
    amount: "$99.00",
    status: "completed",
    timestamp: "6 hours ago",
  },
  {
    id: 4,
    user: "David Brown",
    action: "Purchase",
    amount: "$199.00",
    status: "completed",
    timestamp: "8 hours ago",
  },
  {
    id: 5,
    user: "Emma Davis",
    action: "Signup",
    amount: "Free",
    status: "completed",
    timestamp: "10 hours ago",
  },
];

const statusColors = {
  completed: "bg-green-100 text-green-800",
  pending: "bg-yellow-100 text-yellow-800",
  failed: "bg-red-100 text-red-800",
};

export default function ActivityTable() {
  return (
    <div className="bg-card border border-border rounded-lg p-6 shadow-sm hover:shadow-md hover:-translate-y-0.5 transition-all duration-150 ease-out bg-gradient-to-br from-green-50/20 to-transparent">
      <h3 className="text-lg font-semibold text-foreground mb-4">
        Recent Activity
      </h3>
      <div className="overflow-x-auto">
        <Table>
          <TableHeader>
            <TableRow className="border-border hover:bg-transparent">
              <TableHead className="text-muted-foreground">User</TableHead>
              <TableHead className="text-muted-foreground">Action</TableHead>
              <TableHead className="text-muted-foreground">Amount</TableHead>
              <TableHead className="text-muted-foreground">Status</TableHead>
              <TableHead className="text-muted-foreground">Time</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {activityData.map((row, index) => (
              <TableRow
                key={row.id}
                className={`border-border hover:bg-muted/40 transition-colors duration-150 ${
                  index % 2 === 0 ? "bg-blue-50/30" : ""
                }`}
              >
                <TableCell className="font-medium text-foreground">
                  {row.user}
                </TableCell>
                <TableCell className="text-foreground">{row.action}</TableCell>
                <TableCell className="text-foreground">{row.amount}</TableCell>
                <TableCell>
                  <Badge
                    className={`${
                      statusColors[row.status as keyof typeof statusColors]
                    } text-xs`}
                  >
                    {row.status}
                  </Badge>
                </TableCell>
                <TableCell className="text-muted-foreground text-sm">
                  {row.timestamp}
                </TableCell>
              </TableRow>
            ))}
          </TableBody>
        </Table>
      </div>
    </div>
  );
}
