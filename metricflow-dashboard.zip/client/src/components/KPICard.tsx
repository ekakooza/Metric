import { TrendingDown, TrendingUp } from "lucide-react";
import { ReactNode } from "react";

interface KPICardProps {
  title: string;
  value: string | number;
  trend?: number;
  trendLabel?: string;
  icon?: ReactNode;
  color?: "blue" | "sage" | "rose" | "teal" | "peach";
}

const colorMap = {
  blue: "text-blue-500",
  sage: "text-green-500",
  rose: "text-rose-400",
  teal: "text-teal-500",
  peach: "text-orange-400",
};

const bgColorMap = {
  blue: "bg-blue-100",
  sage: "bg-green-100",
  rose: "bg-rose-100",
  teal: "bg-teal-100",
  peach: "bg-orange-100",
};

export default function KPICard({
  title,
  value,
  trend,
  trendLabel,
  icon,
  color = "blue",
}: KPICardProps) {
  const isPositive = trend && trend > 0;

  return (
    <div className="bg-card border border-border rounded-lg p-6 shadow-sm hover:shadow-md hover:-translate-y-0.5 transition-all duration-150 ease-out bg-gradient-to-br from-blue-50/30 to-transparent">
      <div className="flex items-start justify-between mb-4">
        <h3 className="text-sm font-medium text-muted-foreground">{title}</h3>
        {icon && (
          <div className={`${bgColorMap[color]} p-2.5 rounded-lg`}>
            <div className={colorMap[color]}>{icon}</div>
          </div>
        )}
      </div>

      <div className="mb-4">
        <p className="text-3xl font-bold text-foreground">{value}</p>
      </div>

      {trend !== undefined && (
        <div className="flex items-center gap-1">
          {isPositive ? (
            <TrendingUp className="w-4 h-4 text-emerald-500" />
          ) : (
            <TrendingDown className="w-4 h-4 text-rose-400" />
          )}
          <span
            className={`text-sm font-medium ${
              isPositive ? "text-emerald-600" : "text-rose-600"
            }`}
          >
            {isPositive ? "+" : ""}{trend}%
          </span>
          {trendLabel && (
            <span className="text-xs text-muted-foreground ml-1">
              {trendLabel}
            </span>
          )}
        </div>
      )}
    </div>
  );
}
