import { BarChart3, Home, Settings, TrendingUp } from "lucide-react";
import { ReactNode } from "react";
import { Link } from "wouter";

interface DashboardLayoutProps {
  children: ReactNode;
}

export default function DashboardLayout({ children }: DashboardLayoutProps) {
  return (
    <div className="flex h-screen bg-background">
      {/* Sidebar Navigation */}
      <aside className="w-64 bg-sidebar border-r border-sidebar-border flex flex-col shadow-sm">
        <div className="p-6 border-b border-sidebar-border">
          {/* Logo */}
          <Link href="/">
            <div className="flex items-center gap-3 cursor-pointer hover:shadow-md hover:-translate-y-0.5 transition-all duration-150 ease-out">
              <img
                src="/manus-storage/metricflow-logo_ddfb96dc.png"
                alt="MetricFlow"
                className="w-8 h-8"
              />
              <span className="text-lg font-bold text-sidebar-foreground">
                MetricFlow
              </span>
            </div>
          </Link>
        </div>

        {/* Navigation Items */}
        <nav className="flex-1 p-4 space-y-2">
          <NavItem
            icon={<Home className="w-5 h-5" />}
            label="Dashboard"
            href="/"
            active
          />
          <NavItem
            icon={<TrendingUp className="w-5 h-5" />}
            label="Analytics"
            href="/analytics"
          />
          <NavItem
            icon={<BarChart3 className="w-5 h-5" />}
            label="Reports"
            href="/reports"
          />
        </nav>

        {/* Settings */}
        <div className="p-4 border-t border-sidebar-border">
          <NavItem
            icon={<Settings className="w-5 h-5" />}
            label="Settings"
            href="/settings"
          />
        </div>
      </aside>

      {/* Main Content */}
      <main className="flex-1 overflow-auto">
        <div className="p-8">{children}</div>
      </main>
    </div>
  );
}

interface NavItemProps {
  icon: ReactNode;
  label: string;
  href: string;
  active?: boolean;
}

function NavItem({ icon, label, href, active }: NavItemProps) {
  return (
    <Link href={href}>
      <div
        className={`flex items-center gap-3 px-4 py-2.5 rounded-lg transition-all duration-150 ease-out cursor-pointer ${
          active
            ? "bg-sidebar-accent text-sidebar-primary font-medium"
            : "text-sidebar-foreground hover:bg-sidebar-accent"
        }`}
      >
        {icon}
        <span className="text-sm">{label}</span>
      </div>
    </Link>
  );
}
