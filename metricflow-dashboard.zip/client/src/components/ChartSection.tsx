import {
  BarChart,
  Bar,
  LineChart,
  Line,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend,
  ResponsiveContainer,
} from "recharts";

const chartData = [
  { name: "Mon", revenue: 4000, users: 2400, conversions: 240 },
  { name: "Tue", revenue: 3000, users: 1398, conversions: 221 },
  { name: "Wed", revenue: 2000, users: 9800, conversions: 229 },
  { name: "Thu", revenue: 2780, users: 3908, conversions: 200 },
  { name: "Fri", revenue: 1890, users: 4800, conversions: 221 },
  { name: "Sat", revenue: 2390, users: 3800, conversions: 250 },
  { name: "Sun", revenue: 3490, users: 4300, conversions: 210 },
];

export default function ChartSection() {
  return (
    <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 mb-8">
      {/* Line Chart */}
      <div className="bg-card border border-border rounded-lg p-6 shadow-sm hover:shadow-md hover:-translate-y-0.5 transition-all duration-150 ease-out bg-gradient-to-br from-blue-50/20 to-transparent">
        <h3 className="text-lg font-semibold text-foreground mb-4">
          Revenue Trend
        </h3>
        <ResponsiveContainer width="100%" height={300}>
          <LineChart data={chartData}>
            <CartesianGrid strokeDasharray="3 3" stroke="#e5e7eb" />
            <XAxis stroke="#9ca3af" />
            <YAxis stroke="#9ca3af" />
            <Tooltip
              contentStyle={{
                backgroundColor: "#fff",
                border: "1px solid #e5e7eb",
                borderRadius: "0.65rem",
              }}
            />
            <Legend />
            <Line
              type="monotone"
              dataKey="revenue"
              stroke="#9ec5f0"
              strokeWidth={2.5}
              dot={{ fill: "#9ec5f0", r: 4 }}
              isAnimationActive={true}
            />
          </LineChart>
        </ResponsiveContainer>
      </div>

      {/* Bar Chart */}
      <div className="bg-card border border-border rounded-lg p-6 shadow-sm hover:shadow-md hover:-translate-y-0.5 transition-all duration-150 ease-out bg-gradient-to-br from-rose-50/20 to-transparent">
        <h3 className="text-lg font-semibold text-foreground mb-4">
          Conversions by Day
        </h3>
        <ResponsiveContainer width="100%" height={300}>
          <BarChart data={chartData}>
            <CartesianGrid strokeDasharray="3 3" stroke="#e5e7eb" />
            <XAxis stroke="#9ca3af" />
            <YAxis stroke="#9ca3af" />
            <Tooltip
              contentStyle={{
                backgroundColor: "#fff",
                border: "1px solid #e5e7eb",
                borderRadius: "0.65rem",
              }}
            />
            <Legend />
            <Bar dataKey="conversions" fill="#d9b5b5" radius={[8, 8, 0, 0]} isAnimationActive={true} />
          </BarChart>
        </ResponsiveContainer>
      </div>
    </div>
  );
}
