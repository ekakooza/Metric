# MetricFlow Analytics Dashboard

## Overview

MetricFlow is a clean, minimal analytics dashboard designed for SaaS teams who need clarity without complexity. The dashboard presents key performance indicators, interactive charts, and activity data in a visually cohesive, easy-to-scan layout.

## Design Philosophy: "Soft Clarity"

The dashboard follows a **Soft Clarity** design philosophy that combines minimalism with warmth and approachability:

- **Minimal Aesthetic:** Clean layouts, generous whitespace, and restrained typography
- **Pastel Palette:** Soft, desaturated colors (powder blue, soft sage, pale rose) that reduce eye strain and create a welcoming workspace
- **Rounded Corners:** Soft geometry (0.65rem radius) throughout for a modern, friendly feel
- **Subtle Interactions:** Smooth transitions and hover effects that feel responsive without being distracting

## Core Features

### 1. **Sidebar Navigation**
- Fixed sidebar (240px wide) on the left
- Logo and branding at the top
- Navigation items: Dashboard, Analytics, Reports, Settings
- Active state highlighting with powder blue accent

### 2. **KPI Cards**
Three key metric cards displayed in a responsive grid:
- **Total Revenue:** Shows revenue with trend indicator
- **Active Users:** Displays current active user count with trend
- **Conversions:** Shows conversion count with trend indicator

Each card includes:
- Metric value in large, bold text
- Trend percentage with up/down indicator
- Colored icon badge (powder blue, soft sage, pale rose)
- Hover lift effect for interactivity

### 3. **Filter Bar**
Located below the page header, allows users to:
- Select date range (Last 7 days, 30 days, 90 days, 1 year)
- Filter by segment (All, Premium, Standard, Free)
- Reset filters to default state

### 4. **Charts Section**
Two side-by-side charts (stacked on mobile):
- **Revenue Trend (Line Chart):** Shows revenue progression over time with smooth curve
- **Conversions by Day (Bar Chart):** Displays daily conversion counts with rounded bars

Both charts use pastel colors and include interactive tooltips.

### 5. **Activity Table**
Recent activity log showing:
- User name
- Action type (Purchase, Signup, Upgrade)
- Transaction amount
- Status badge (Completed, Pending, Failed)
- Timestamp

Features:
- Alternating row backgrounds for readability
- Status badges with color coding
- Hover effects for interactivity
- Responsive scrolling on mobile

## Color Palette

| Color | OKLCH Value | Usage |
|-------|-------------|-------|
| Powder Blue | oklch(0.80 0.08 260) | Primary accent, charts, active states |
| Soft Sage | oklch(0.85 0.05 145) | Secondary accent, positive metrics |
| Pale Rose | oklch(0.88 0.04 15) | Warnings, conversions chart |
| Off-white | oklch(0.98 0.001 286) | Main background |
| Soft Cream | oklch(0.99 0.001 80) | Card backgrounds |
| Dark Slate | oklch(0.235 0.015 65) | Text foreground |

## Typography

- **Display Font:** System UI / Geist (modern, geometric)
- **Body Font:** Inter (clean, highly legible)
- **Hierarchy:**
  - Page Title (H1): 36px, 700 weight
  - Section Titles (H2): 20px, 600 weight
  - Card Labels (H3): 14px, 600 weight
  - Body Text: 14px, 400 weight
  - Small Text: 12px, 400 weight

## Responsive Design

- **Desktop:** Full layout with sidebar and two-column charts
- **Tablet:** Sidebar visible, charts stack vertically
- **Mobile:** Sidebar collapses to hamburger menu (future enhancement)

## Component Structure

```
client/src/
├── components/
│   ├── DashboardLayout.tsx      # Main layout with sidebar
│   ├── KPICard.tsx              # Individual KPI card component
│   ├── FilterBar.tsx            # Date range and segment filters
│   ├── ChartSection.tsx         # Line and bar charts
│   └── ActivityTable.tsx        # Recent activity table
├── pages/
│   └── Home.tsx                 # Dashboard page
└── index.css                    # Global styles and theme
```

## Interactions & Animations

- **Hover Effects:** Cards lift slightly on hover with increased shadow
- **Transitions:** All state changes use 150ms ease-out timing
- **Chart Animations:** Charts animate in on load
- **Focus States:** Keyboard focus rings use powder blue with 2px outline

## Future Enhancements

- Mobile sidebar collapse/expand
- Date picker for custom date ranges
- Export functionality for reports
- Real-time data updates
- Customizable dashboard widgets
- Dark mode support
- Additional chart types (pie, area, scatter)

## Technical Stack

- **Framework:** React 19
- **Styling:** Tailwind CSS 4 with custom theme
- **Charts:** Recharts
- **UI Components:** shadcn/ui
- **Icons:** Lucide React
- **Routing:** Wouter

## Getting Started

The dashboard is built as a static React application. To run locally:

```bash
pnpm install
pnpm dev
```

The development server will start at `http://localhost:3000/`

## Design Tokens

All design tokens are defined in `client/src/index.css` using CSS custom properties:

- `--primary`: Powder blue accent
- `--background`: Off-white main background
- `--card`: Soft cream card background
- `--border`: Light gray borders
- `--radius`: 0.65rem (soft rounded corners)

Modify these values to adjust the entire design system globally.

## Accessibility

- All interactive elements are keyboard accessible
- Focus indicators are always visible
- Color contrast meets WCAG AA standards
- Semantic HTML structure for screen readers
- Icons are paired with text labels

---

**Design Philosophy:** Clarity through restraint. Every element serves a purpose. Every color choice reduces eye strain. Every interaction feels responsive and intentional.
